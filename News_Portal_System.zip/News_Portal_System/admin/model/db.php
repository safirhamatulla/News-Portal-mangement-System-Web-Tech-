<?php 

$connection = mysqli_connect('localhost','root','','news_portal') or die("Not Connected". mysqli_error());

?>