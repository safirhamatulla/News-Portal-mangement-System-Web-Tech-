<!DOCTYPE html>
<html>
    <title>News Portal Website</title>
    <head></head>
    <body style="margin:0">
<!-- Start Header -->
        
        <table border ="0" width = "100%" cellpadding ="0" cellspacing="0" bgcolor="">
            <tr>
                <td>
                    <table border="0" width ="100%"  cellpadding="0" cellspacing ="0" align="center" bgcolor="#FFFFFF">
                        <!-- <td><img src="" style="width:70%;height:20%"></td> -->
                        <td align="center"style="font-family: Arial"><h1><strong>News Portal System</strong></h1></td>
                        <!--<td align="right"style="font-family: Arial, Helvetica, sans-serif;"><strong>Login</strong> OR <strong>Rgister</strong> </td>-->
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table border="1" width="100%" cellpadding="15" cellspacing ="1" align="center" bgcolor="#247CC6">
                        <td>
                            <a href="admin/index.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    Admin
                                </font>
                            </a>
                        </td>
                        <td>
                            <a href="User/index.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    User
                                </font>
                            </a>
                        </td>
                        <td>
                            <a href="journalist/index.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    Journalist
                                </font>
                                
                            </a>
                        </td>
                        <td>
                            <a href="Publisher/index.php">
                                <font face="Arial" color="#ffffff" size="4">
                                    Publisher
                                </font>
                            </a>
                        </td>
                        
                    </td>
                    </table>
                </td>
            </tr>
        </table>
<!-- End Header -->

    </body>
</html>